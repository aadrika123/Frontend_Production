
AndroidInterface.btPrinter("<nc>New Swm Payment Receipt</nc><br />")