function n(e){return e instanceof Error?e.message:String(e)}export{n as g};
