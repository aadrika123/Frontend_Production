import{j as t}from"./index-DKX_p4W9.js";function n(){return t.jsx("div",{className:"flex h-96 items-center justify-center",children:"AttendanceList"})}export{n as default};
